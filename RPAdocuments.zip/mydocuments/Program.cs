static void Main(String[] args)
{
    
}


public static void PrintLetter()
{
    String txt = "Uipath Automation Is the No 01 @ Chennai";
    char txt1 = ""
    char [] allChar = txt.ToCharArray();
    foreach (char eachChar in allChar)
    {
        if (char.isLower(eachChar))
        {
            txt1 = txt1 + char.ToUpper(eachChar);
        }
        else
        {
            txt1
        }
    }

 Dictionary<   
}