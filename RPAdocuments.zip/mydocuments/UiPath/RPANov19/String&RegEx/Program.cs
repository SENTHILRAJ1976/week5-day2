﻿using System;


namespace LearnCustUipath
{
    class Program
    {
        static void Main(string[] args)
        {
            string text1 = "I am New to and Learning is Fun";
            string text2 = "Uipath";
            char ch = 'a';
            Console.WriteLine($"I am New to {text2} and Learning {text2} is Fun");
            Console.WriteLine(text1.LastIndexOf('a'));
            // Console.WriteLine(text.Length);
            // Console.WriteLine(text[3]);
            //  Console.WriteLine(text1 + text2);
            //string[] allText = text1.Split(' ');
            //Console.WriteLine(allText[0]);
            //String txt = "";
            //foreach (string eachValue in allText)
            //{   if (eachValue.Equals("to"))
            //        txt = txt + eachValue + " "+text2;
            //else
            //        txt = txt + " "+eachValue
            //    Console.WriteLine(eachValue);
            //}
            //text1.Insert(10, text2);

        }
    }
}
