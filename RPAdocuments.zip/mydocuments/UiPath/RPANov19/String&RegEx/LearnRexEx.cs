﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;



namespace LearnCustUipath
{
    class LearnRexEx
    {
        static void Main(string[] args)
        {
            string text = "UiPath Certification in 2019 and more than 2000 got certified last year across globe";
            string patt = "\\d{4}";

            MatchCollection allMatch = Regex.Matches(text, patt);
            
            foreach(Match eachMatch in allMatch)
            {
                Console.WriteLine(eachMatch);
            }







            //[abc]
            //[123]
            //[a-zA-Z]
            //[0-9]
            //[^c-e]
            //[^0-9]
            // \d -> 0-9 not -> \D
            // \w -> a-zA-Z0-9  not -> \W
            // \s not -> \S
            //{n} -> ex => {4}
            //{n,m} ex=> {4,6}
            //{n,} ex=> {1,}
            //* 	Zero or more repetitions 
            //+ 	One or more repetitions
            //Ex-> [10]{1,}













        }

    }
}
